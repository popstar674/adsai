from flask import Flask, request, jsonify
import openai
import os

app = Flask(__name__)

openai.api_key = os.getenv("OPENAI_API_KEY")

@app.route("/generate-ad", methods=["POST"])
def generate_ad():
    data = request.json
    description = data.get("description")
    platform = data.get("platform")
    format_type = data.get("format")

    prompt = f"""
You are an expert ad creator. Based on the input below, create a high-converting social media ad:
Product Description: {description}
Platform: {platform}
Format: {format_type}

Return in JSON format:
- title
- ad_text
- call_to_action
- hashtags (comma-separated)
- image_prompt (a DETAILED scene description of the ad)
"""

    response = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[{"role": "user", "content": prompt}],
        temperature=0.7
    )

    try:
        text_response = response["choices"][0]["message"]["content"]
        return jsonify({"ad": text_response})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)