# adsai
AI-powered ad generator API for social media platforms.